# LogFilter

These are the available filters for downloading logs. We match these filters against the log file path/name (or object attributes) to identify which log files to return to the frontend.  These are mutually exclusive:     {cluster_id, job_id, job_run}     {actor_id, process_id, task_id}
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cluster_id** | **str** | Filter logs by cluster_id. | [optional] 
**job_id** | **str** | Filter logs by job_id (Anyscale Job ID). | [optional] 
**job_run** | **str** | Filter logs by job_run_id (Anyscale Job Run ID). | [optional] 
**glob** | **str** | Filter logs by a glob filter. | [optional] 
**node_ip** | **str** | Filter logs by node_ip (Internal Node IP). | [optional] 
**instance_id** | **str** | Filter logs by instance_id (Cloud Provider Instance ID). | [optional] 
**node_type** | [**NodeType**](NodeType.md) | Filter logs by node_type (head-node, worker-nodes). | [optional] 
**actor_id** | **str** | Filter logs by actor_id. | [optional] 
**process_id** | **str** | Filter logs by process_id. | [optional] 
**task_id** | **str** | Filter logs by task_id. | [optional] 
**session_id** | **str** | Filter logs by session_id. | [optional] 
**file_name** | **str** | Filter logs by log file name. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


