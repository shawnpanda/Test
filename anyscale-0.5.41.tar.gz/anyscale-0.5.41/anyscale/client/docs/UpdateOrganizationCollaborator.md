# UpdateOrganizationCollaborator

Modifiable fields for an organzation collaborator
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**permission_level** | [**OrganizationPermissionLevel**](OrganizationPermissionLevel.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


