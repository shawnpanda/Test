# OnboardingUserCardsQuery

Query object used to search OnboardingUserCards.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**card_ids** | [**list[CardId]**](CardId.md) | Search active card ids in this list. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


