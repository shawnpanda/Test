from typing import Optional


AWS_PROFILE = None


# Global variable that contains the server session token.
CLI_TOKEN: Optional[str] = None

TEST_V2 = False


ANYSCALE_IAM_ROLE_NAME = "anyscale-iam-role"
