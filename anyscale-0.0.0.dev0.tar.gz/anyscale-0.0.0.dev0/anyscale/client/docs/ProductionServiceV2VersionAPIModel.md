# ProductionServiceV2VersionAPIModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** | Time the version was created | 
**weight** | **int** | The percentage of traffic sent to this version. This is a number between 0 and 100. | 
**version** | **str** | The version string identifier for this version | 
**ray_serve_config** | [**object**](.md) |  | 
**build_id** | **str** | The id of the cluster env build. This id will determine the docker image your Service is run using. | 
**compute_config_id** | **str** | The id of the compute configuration that you want to use. This id will specify the resources required for your Service.The compute template includes a &#x60;cloud_id&#x60; that cannot be updated. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


