# PythonModules

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pip_packages** | **list[str]** | List of pip packages that&#39;ll be included in the image. | [optional] 
**conda_packages** | **list[str]** | List of conda packages that&#39;ll be included in the image. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


