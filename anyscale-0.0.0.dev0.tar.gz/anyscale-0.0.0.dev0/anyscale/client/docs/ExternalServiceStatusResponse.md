# ExternalServiceStatusResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metrics_dashboard_status** | [**ExternalServiceStatus**](ExternalServiceStatus.md) |  | [optional] 
**persistent_metrics_status** | [**ExternalServiceStatus**](ExternalServiceStatus.md) |  | [optional] 
**jupyter_noteboook_status** | [**ExternalServiceStatus**](ExternalServiceStatus.md) |  | [optional] 
**service_proxy_status** | [**ExternalServiceStatus**](ExternalServiceStatus.md) |  | [optional] 
**ray_dashboard_status** | [**ExternalServiceStatus**](ExternalServiceStatus.md) |  | [optional] 
**webterminal_status** | [**ExternalServiceStatus**](ExternalServiceStatus.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


