# NodeRegistrationGCP

Information from the GCP VM Instance Metadata Service that proves the identity of that node.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id_token** | **str** | ID Token for Service Account running on GCP. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


