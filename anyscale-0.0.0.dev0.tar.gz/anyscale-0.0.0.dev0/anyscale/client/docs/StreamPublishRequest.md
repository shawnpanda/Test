# StreamPublishRequest

A request to produce an event to a topic (through the API Pod Producer Router + Streaming Service).
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**topic** | **str** | A topic to publish this event into. | 
**key** | **str** | A partitioning key for the event; all events emitted with a single key will be read in-order (usually cloud ID, cluster ID, etc.) | 
**message** | **str** | A JSON-serialized protobuf message body. | 
**message_type** | **str** | The type of protobuf that we want to publish (e.g. protobuf message type name). | 
**timestamp** | **datetime** | The time (in UTC) at which this event occurred. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


