# ServeDeploymentGrafanaDashboardStatus

ServeDeploymentGrafanaDashboardStatus is a control plane defined Enum which is used determine if the grafana dashboards for a deployment is being created, created or offline. in the control plane.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


