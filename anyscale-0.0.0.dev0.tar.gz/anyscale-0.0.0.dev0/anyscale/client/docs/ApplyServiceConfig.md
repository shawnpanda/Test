# ApplyServiceConfig

The API model to apply a Service.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**service_v1_config** | [**CreateProductionService**](CreateProductionService.md) | The configuration of Service V1 | [optional] 
**service_v2_config** | [**ApplyProductionServiceV2APIModel**](ApplyProductionServiceV2APIModel.md) | The configuration of Service V2 | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


