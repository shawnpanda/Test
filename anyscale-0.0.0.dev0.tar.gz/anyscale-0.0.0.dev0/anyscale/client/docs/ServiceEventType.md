# ServiceEventType

All possible event types for a service  These are the event types that will be shown in the event log. They include both user initiated actions, and state changes.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


