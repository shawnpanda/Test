# DecoratedSupportRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | 
**requester_id** | **str** |  | 
**organization_id** | **str** |  | 
**requested_at** | **datetime** |  | 
**expires_at** | **datetime** |  | 
**requester** | [**MiniUser**](MiniUser.md) |  | 
**organization** | [**MiniOrganization**](MiniOrganization.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


