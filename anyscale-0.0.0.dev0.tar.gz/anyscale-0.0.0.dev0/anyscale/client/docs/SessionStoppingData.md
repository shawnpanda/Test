# SessionStoppingData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stop_progress** | **str** |  | [optional] 
**stop_error** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


