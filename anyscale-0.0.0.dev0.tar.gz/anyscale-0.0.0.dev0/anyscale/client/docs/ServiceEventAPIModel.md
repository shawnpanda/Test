# ServiceEventAPIModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Id of the service event | 
**created_at** | **datetime** | The last time the state of this job was updated. This includes updates to the state and to the goal state | 
**event_type** | [**ServiceEventType**](ServiceEventType.md) | Type of Service Event | 
**level** | [**ServiceEventLevel**](ServiceEventLevel.md) |  | [optional] 
**message** | **str** |  | [optional] 
**user_id** | **str** | Present only for goal state changes | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


