# EventsServicePublishRequest

This is deprecated - see `streams.py` instead.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**topic** | **str** | The topic to publish this event to. | 
**partition** | **str** | The partition key to publish this event to. | 
**payload** | **str** | A payload in bytes containing the event message. This should be a serialized version of the google.protobuf.any_pb2.Any message type. | 
**event_time** | **int** | The time (in milliseconds) at which this event occurred. | 
**maxlen** | **str** | If maxlen is specified, old entries are automatically evicted when the specified length is reached, so that the stream is always a constant size. | [optional] 
**minid** | **str** | If minid is specified, entries older than minid are evicted. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


