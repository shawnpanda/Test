# ApplyProductionServiceV2APIModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the Service | 
**description** | **str** | Description of the Service | [optional] 
**project_id** | **str** | Id of the project this Service will start clusters in | 
**version** | **str** | A version string that represents the version for this service. Will be populated with the hash of the config if not specified. | [optional] 
**canary_percent** | **int** | A manual target percent for this service. If this field is not set, the service will automatically roll out. If set, this should be a number between 0 and 100. The newly created version will have weight &#x60;canary_percent&#x60; and the existing version will have &#x60;100 - canary_percent&#x60;. | [optional] 
**canary_weight** | **int** | DEPRECATED: please use &#39;canary_percent&#39;. | [optional] 
**ray_serve_config** | **object** | The Ray Serve config to use for this service. This config defines your Ray Serve application, and will be passed directly to Ray Serve. You can learn more about Ray Serve config files here: https://docs.ray.io/en/latest/serve/production-guide/config.html | 
**build_id** | **str** | The id of the cluster env build. This id will determine the docker image your Service is run using. | 
**compute_config_id** | **str** | The id of the compute configuration that you want to use. This id will specify the resources required for your ServiceThe compute template includes a &#x60;cloud_id&#x60; that must be fixed for each service. | 
**rollout_strategy** | [**RolloutStrategy**](RolloutStrategy.md) | Strategy for rollout. The ROLLOUT strategy will deploy your Ray Serve configuration onto a newly started cluster, and then shift traffic over to the new cluster. You can manually control the speed of the rollout using the canary_weight configuration. The IN_PLACE strategy will use Ray Serve in place upgrade to update your existing cluster in place. When using this rollout strategy, you may only change the ray_serve_config field. You cannot partially shift traffic or rollback an in place upgrade. In place upgrades are faster and riskier than rollouts, and we recommend only using them for relatively safe changes (for example, increasing the number of replicas on a Ray Serve deployment). Default strategy is ROLLOUT. | [optional] 
**ray_gcs_external_storage_config** | [**RayGCSExternalStorageConfig**](RayGCSExternalStorageConfig.md) | Config for the Ray GCS to connect to external storage. If populated, head node fault tolerance will be enabled for this service. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


