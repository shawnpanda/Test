# ApplyProductionServiceV2APIModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the Service | 
**description** | **str** | Description of the Service | [optional] 
**project_id** | **str** | Id of the project this Service will start clusters in | 
**version** | **str** | A version string that represents the version for this service. Will be populated with the hash of the config if not specified. | [optional] 
**canary_weight** | **int** | A manual target weight for this service. If this field is not set, the service will automatically roll out. If set, this should be a number between 0 and 100. The newly created version will have weight &#x60;canary_weight&#x60; and the existing version will have &#x60;100 - canary_weight&#x60;. | [optional] 
**ray_serve_config** | **object** | The Ray Serve config to use for this service. This config defines your Ray Serve application, and will be passed directly to Ray Serve. You can learn more about Ray Serve config files here: https://docs.ray.io/en/latest/serve/production-guide/config.html | 
**build_id** | **str** | The id of the cluster env build. This id will determine the docker image your Service is run using. | 
**compute_config_id** | **str** | The id of the compute configuration that you want to use. This id will specify the resources required for your ServiceThe compute template includes a &#x60;cloud_id&#x60; that must be fixed for each service. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


