# InteractiveSessionLogs

The logs for this InteractiveSessionLogs
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**logs** | **str** | Logs of this entity | 
**ready** | **bool** |              Indicates if underlying logs service is ready to use.             If false, clients will need to request for logs until this field is True.          | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


