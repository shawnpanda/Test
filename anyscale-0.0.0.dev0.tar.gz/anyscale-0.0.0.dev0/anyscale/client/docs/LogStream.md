# LogStream

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**http_url** | **str** | HTTP URL for retrieving initial lines. | 
**stream_url** | **str** | HTTP/WebSocket URL for streaming Ray logs. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


