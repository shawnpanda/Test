# DecoratedListServiceAPIModel

Shared base model for both Service v1 and v2. It should not be used directly.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | 
**name** | **str** |  | 
**created_at** | **datetime** | Time the Service was created | 
**project_id** | **str** | Id of the project this Service will start clusters in. This configuration cannot be changed after the service is created. | 
**current_state** | [**ServiceEventCurrentState**](ServiceEventCurrentState.md) | The current state of this service | 
**endtime** | **datetime** |  | [optional] 
**type** | [**ServiceType**](ServiceType.md) | Type of the Service | 
**creator** | [**MiniUser**](MiniUser.md) | The creator of this service | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


