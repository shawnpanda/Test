# MiniJobRun

The MiniJobRun fetches a BaseJob and decorates it with     - cluster     - integration_details  This is more performant than using DecoratedJob because it fetches much less additional information
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | 
**ray_session_name** | **str** |  | 
**ray_job_id** | **str** |  | 
**name** | **str** |  | [optional] 
**status** | [**BaseJobStatus**](BaseJobStatus.md) |  | 
**created_at** | **datetime** |  | 
**finished_at** | **datetime** |  | [optional] 
**ha_job_id** | **str** |  | [optional] 
**ray_job_submission_id** | **str** |  | [optional] 
**cluster_id** | **str** |  | 
**namespace_id** | **str** | ID of the Anyscale Namespace. | [optional] [default to 'DEPRECATED_NAMESPACE_ID']
**environment_id** | **str** |  | 
**project_id** | **str** |  | [optional] 
**creator_id** | **str** |  | 
**integration_execution_details_id** | **str** |  | [optional] 
**bucket_log_prefix** | **str** |  | [optional] 
**cluster** | [**MiniCluster**](MiniCluster.md) |  | 
**integration_details** | [**IntegrationDetails**](IntegrationDetails.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


