# FeatureCompatibility

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_compatible** | **bool** | Returns true if a feature is compatible with a ray version | 
**compatibility_message** | **str** | A string indicating the available ray versions | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


