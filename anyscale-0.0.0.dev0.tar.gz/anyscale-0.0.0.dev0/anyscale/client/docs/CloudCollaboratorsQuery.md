# CloudCollaboratorsQuery

Query object used to search Cloud Collaborators.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name_or_email** | [**TextQuery**](TextQuery.md) | Filters cloud collaborators by name and ORs the result with cloud collaborators filtered by email. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


