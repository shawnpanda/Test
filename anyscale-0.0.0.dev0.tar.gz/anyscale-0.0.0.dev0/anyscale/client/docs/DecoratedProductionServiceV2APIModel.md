# DecoratedProductionServiceV2APIModel

Shared model to be inherited. It should not be used directly.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Id of the Service | 
**name** | **str** | Name of the Service | 
**description** | **str** | Description of the Service | [optional] 
**project_id** | **str** | Id of the project this Service will start clusters in. This configuration cannot be changed after the service is created. | 
**cloud_id** | **str** | Id of the cloud this Service belongs to, and will launch clusters in. This configuration cannot be changed. | 
**creator_id** | **str** | Id of the user who created the Service | 
**created_at** | **datetime** | Time the Service was created | 
**hostname** | **str** | The hostname of the service | 
**current_state** | [**ServiceEventCurrentState**](ServiceEventCurrentState.md) | The current state of this service | 
**goal_state** | [**ServiceGoalStates**](ServiceGoalStates.md) | The goal state of this service | 
**auth_token** | **str** | Token to use for service auth. To use the token, add it as a header with the key &#39;Authorization&#39; and the value &#39;Bearer &lt;token&gt;&#39; | 
**auto_rollout_enabled** | **bool** | Whether or not the service is using auto rollout | 
**versions** | [**list[DecoratedProductionServiceV2VersionAPIModel]**](DecoratedProductionServiceV2VersionAPIModel.md) | Active versions of this service, sorted by creation time in ascending order. | 
**creator** | [**MiniUser**](MiniUser.md) | The creator of this service | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


