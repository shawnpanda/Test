# ComputeNodeType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | An arbitrary name for this node type, which will be registered with OSS available_node_types.  | 
**instance_type** | **str** | The cloud provider instance type to use for this node. | 
**resources** | [**Resources**](Resources.md) | Declaration of node resources for Autoscaler. | [optional] 
**aws_advanced_configurations_json** | [**object**](.md) | The advanced configuration json that we pass directly AWS APIs when launching an instance. We may do some validation on this json and reject the json if it is using a configuration that Anyscale does not support. | [optional] 
**aws_advanced_configurations** | [**AWSNodeOptions**](AWSNodeOptions.md) | DEPRECATED: Please provide instance configuration in the &#x60;aws_advanced_configurations_json&#x60; field. Additional AWS-specific configurations can be specified per node type and they will override the configuration specified for the whole cloud. | [optional] 
**gcp_advanced_configurations_json** | [**object**](.md) | The advanced configuration json that we pass directly GCP APIs when launching an instance. We may do some validation on this json and reject the json if it is using a configuration that Anyscale does not support. | [optional] 
**gcp_advanced_configurations** | [**GCPNodeOptions**](GCPNodeOptions.md) | DEPRECATED: Please provide instance configuration in the &#x60;gcp_advanced_configurations_json&#x60; field. Additional GCP-specific configurations can be specified per node type and they will override the configuration specified for the whole cloud. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


