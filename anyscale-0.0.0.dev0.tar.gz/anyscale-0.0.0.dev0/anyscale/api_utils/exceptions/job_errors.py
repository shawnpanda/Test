class NoJobRunError(Exception):
    pass
